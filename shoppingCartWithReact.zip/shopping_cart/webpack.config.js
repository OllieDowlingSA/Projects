var env = process.env.NODE_ENV || process.env.RAILS_ENV || 'development'
var path = require('path');
global.RAILS_ROOT = __dirname;
console.log("Loading Webpack Config ("+env+")");
module.exports = require("./config/webpack/"+env);
require 'test_helper'

class Api::ProductsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

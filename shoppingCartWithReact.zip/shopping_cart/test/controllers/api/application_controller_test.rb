require 'test_helper'

class Api::ApplicationControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end

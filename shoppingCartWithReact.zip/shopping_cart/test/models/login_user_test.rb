require 'test_helper'

class LoginUserTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

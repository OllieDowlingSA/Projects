# Load the Rails application.
require File.expand_path('../application', __FILE__)

# Initialize the Rails application.
Rails.application.initialize! do |config|
  config.action_controller.session = {
    :session_key => '_store_session',
    #expire token after 1 year
    :secret => '851939c37d94574e284ded8437d4ea3447dae24cc5bda61d8eaf2731d49273bc4c620', :expire_after => 1.year
  }
end


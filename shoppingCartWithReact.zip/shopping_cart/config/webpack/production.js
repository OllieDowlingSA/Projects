var webpack = require('webpack');
var CompressionPlugin = require("compression-webpack-plugin");

config = {
  context: RAILS_ROOT + "/client",
  entry: ["./boot"],
  output: {
    path: './public/assets',
    publicPath: '/assets/',
    filename: 'app-bundle-[hash].js'
  },
  resolve: {
    modulesDirectories: ["./node_modules", './client'],
    extensions: ['', '.js', '.jsx', '.cjsx', '.coffee']
  },
  module: {
    loaders: [
      { test: /\.json$/, loader: "json" },
      { test: /\.coffee$/, loader: "coffee" },
      { test: /\.jsx$/, loaders: ["jsx?insertPragma=React.DOM"] },
      { test: /\.cjsx$/, loaders: ["coffee", "cjsx?insertPragma=React.DOM"] },
      { test: /\.css$/, loaders: ["style","css"] }
    ]
  },
  plugins: [
    new webpack.ProvidePlugin({"React": "react/addons"}),
    new webpack.optimize.MinChunkSizePlugin({minChunkSize: 50000}),
    new webpack.optimize.CommonsChunkPlugin({children: true}),
    new webpack.optimize.UglifyJsPlugin({mangle: {except: ['$super']}}),
    new CompressionPlugin()
  ]
}

module.exports = config
var webpack = require('webpack');
var glob = require('glob');
var WebpackNotifierPlugin = require('webpack-notifier');
devServerPort = 5001;

config = {
  context: RAILS_ROOT + "/client",
  entry: ['webpack-dev-server/client?http://localhost:'+devServerPort,'webpack/hot/only-dev-server','./boot'],
  output: {
    path: './public/assets',
    publicPath: "http://localhost:"+devServerPort+"/assets/",
    filename: 'app-bundle.js'
  },
  resolve: {
    modulesDirectories: ["./node_modules", './client'],
    extensions: ['', '.js', '.jsx', '.cjsx', '.coffee']
  },
  module: {
    loaders: [
      { test: /\.json$/, loader: "json" },
      { test: /\.coffee$/, loader: "coffee" },
      { test: /\.jsx$/, loaders: ["react-hot", "jsx?insertPragma=React.DOM"] },
      { test: /\.cjsx$/, loaders: ["react-hot", "coffee", "cjsx?insertPragma=React.DOM"] },
      { test: /\.css$/, loaders: ["style","css"] }
    ]
  },
  plugins: [
    new webpack.HotModuleReplacementPlugin(),
    new webpack.NoErrorsPlugin(),
    new webpack.ProvidePlugin({"React": "react/addons"}),
    new WebpackNotifierPlugin()
  ],
  devServer: {
    port: devServerPort,
    contentBase: "./public/assets",
    info: false, //  --no-info option
    hot: true,
    inline: true
  },
  // devtool: "#inline-source-map"
}

module.exports = config
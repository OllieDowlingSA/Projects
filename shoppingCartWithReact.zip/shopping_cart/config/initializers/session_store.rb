# Be sure to restart your server when you modify this file.


#expire session after 1 year
Rails.application.config.session_store :cookie_store, key: '_shopping_cart_session', :expire_after => 1.year


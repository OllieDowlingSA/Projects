# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
AdminUser.create!(email: 'admin@shopping_cart.com', password: 'password123', password_confirmation: 'password123')

Product.create!(title: 'Pink-coat', image_url: 'http://i01.i.aliimg.com/img/pb/335/047/829/829047335_356.jpg', price: 200.00, description: 'nice winter jacket', in_stock: true)
Product.create!(title: 'Sweat-shirt', image_url: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqXmPvsbrq0XCm1Khb84KBKD3rhHnpIxtIwOoBewDhusSCgzOYYg', price: 40.00, description: 'nice cool sweat shirt', in_stock: true)  
Product.create!(title: 'Cool-bags', image_url: 'http://g02.a.alicdn.com/kf/HTB1Y.nNIXXXXXXyXFXXq6xXFXXXO.jpg', price: 30.00, description: 'nice cool bags', in_stock: true)  
Product.create!(title: 'Black-shoe', image_url: 'http://realmenrealstyle.com/wp-content/uploads/2012/11/black-oxford-large1.jpg', price: 80.00, description: 'nice leather black shoe', in_stock: true) 
Product.create!(title: 'Cool-Chair', image_url: 'http://www.funcage.com/blog/wp-content/uploads/2011/05/Chase-Lounge.jpg', price: 240.00, description: 'cool, creative and comfy', in_stock: true) 
Product.create!(title: 'Great-table', image_url: 'http://tabletennisnation.com/wp-content/uploads/2014/02/marble-table-tennis.jpg', price: 330.00, description: 'Great table for bringing out creative you!', in_stock: true) 

User.create!(email: "sam@pmail.com", password: 'secret123')
User.create!(email: "sree@tmail.com", password: 'secret123')
User.create!(email: "sreelatha@qmail.com", password: 'secret123')



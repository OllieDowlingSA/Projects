class CreateProducts < ActiveRecord::Migration
  def change
    create_table :products do |t|
      t.string :title
      t.string :image_url
      t.decimal :price, precision: 8, scale: 2
      t.string :description
      t.boolean :in_stock

      t.timestamps null: false
    end
  end
end

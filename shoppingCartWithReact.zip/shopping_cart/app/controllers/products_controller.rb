class ProductsController < ApplicationController
  before_action :authenticate_user!, :except => [:index, :show]

  def create
    product = Product.create(product_params)
  end   
  def index
    @products = Product.all
  end

  def show
    @products = Product.all
    @product = Product.find_by_id(params[ :id])
  end 
  def update
    @product = Product.update(product_params)
  end  

  def destroy
    @product = Product.find_by_id(params[ :id])  
    @product.destroy     
  end

  #private

    # def product_params
    #   params.require(:product).permit(:title, :image_url, :price, :description, :in_stock)
    # end
end

class OrdersController < ApplicationController
  
  def show
    @order = Order.find_by_id(params[ :id])
  end  

  def create
   @order =  Order.create!(user_id: @user.id, is_complete: false)
  end  
 
 def update
  @order = Order.find_by_id(params[ :id])
  @order.update(is_complete: true)
  @order.save
  redirect_to :action => "show"
 end

 def destroy
  @order = Order.find_by_id(params[ :id])
  @order.destroy
  redirect_to products_path, :notice => ""
 end
end
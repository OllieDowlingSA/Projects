class Api::ApplicationController < ApplicationController
  respond_to :json
  def current_order

    @current_order = Order.where(user_id: current_user.id, is_complete: false).first   
    
    if !@current_order
      @current_order =  Order.create!(user_id: current_user.id, is_complete: false)
      render json: @current_order
        #session[:order_id] = @current_order.id
      end      
      @current_order
    end    
  end


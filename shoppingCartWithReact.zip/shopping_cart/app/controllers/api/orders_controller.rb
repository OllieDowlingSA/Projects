class Api::OrdersController < ApplicationController
  respond_to :json

  def show
    @order = Order.find_by_id(params[ :id])
    render json: @order
  end  
end

class Api::OrderItemsController < ApplicationController
  respond_to :json

  def index    
    @order_items = OrderItem.where(order_id: @order.id).all
    render json: @order_items
  end

  def show 
    @product = Product.find_by_id(@order_item.product_id)
    render json: @product
  end 
end

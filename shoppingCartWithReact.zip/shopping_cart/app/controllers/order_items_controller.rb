class OrderItemsController < ApplicationController
  
  before_action :authenticate_user!

  before_action  :set_order

  def index 
   
    @order_items = OrderItem.where(order_id: @order.id).all
    #puts "Debugging=&&&&&&&&&&&&&&&&&= #{@order.id}" 
  end

  def show 
    @product = Product.find_by_id(@order_item.product_id)
  end 

  def new
    @order_item = OrderItem.create
  end

  def create 
    @product = Product.find_by_id(params[ :product_id])
    
    order_item = OrderItem.create(order_id: @order.id, product_id: @product.id, price: @product.price)

    if order_item 
     redirect_to :action => "index" 
   else 
     redirect_to products_path
   end    
 end

 def destroy 
  @order_item = OrderItem.find_by_id(params[ :id])
  @order_item.destroy
  redirect_to order_items_path
end

def set_order
    #calls current_order method from application controller
    @order = current_order
  end  
  
end



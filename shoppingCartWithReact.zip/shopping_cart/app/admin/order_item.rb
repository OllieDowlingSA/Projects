ActiveAdmin.register OrderItem do
  #config.clear_action_items!

   
   permit_params :order_id, :product_id, :price

end
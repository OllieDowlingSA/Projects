ActiveAdmin.register Order do


# See permitted parameters documentation:
# https://github.com/activeadmin/activeadmin/blob/master/docs/2-resource-customization.md#setting-up-strong-parameters
#
# permit_params :list, :of, :attributes, :on, :model
#
# or
#
# permit_params do
#   permitted = [:permitted, :attributes]
#   permitted << :other if resource.something?
#   permitted
# end
  config.clear_action_items!
  permit_params :user_id, :is_complete
  actions :all
  
  show do |order|
    attributes_table do
      row :id
      row :user_id
      row :is_complete
      # row :order_items do |order|
      #     order.order_items.each do |order_item|
      #        order_item.product_id  
      #     end
      #   end
      row :created_at
      row :updated_at
    end
  end  
  
end

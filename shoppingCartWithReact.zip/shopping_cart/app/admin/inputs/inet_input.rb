class InetInput < Formtastic::Inputs::StringInput
   
end
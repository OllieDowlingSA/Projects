
ActiveAdmin.register_page "Dashboard" do
  content :title => proc{ I18n.t("active_admin.dashboard") } do
    section "Recent Products" do
      table_for Product.order("created_at desc").limit(5) do
        column :title do |product|
          link_to product.title, admin_product_path(product)
        end
        column :created_at
        column :description
        column :in_stock
        column :price
        column "Image" do |product|
          image_tag product.image_url, class: 'my_image_size'

        end
      end
    end
    strong { link_to "View All Products", admin_products_path }
  end
end


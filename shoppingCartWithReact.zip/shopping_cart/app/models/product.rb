class Product < ActiveRecord::Base
  alias_attribute :name, :title
  validates :title, :presence => true
  validates :price, :presence => true
  has_many :order_items
  before_destroy :ensure_not_referenced_by_any_order_item
 
  
  def ensure_not_referenced_by_any_order_item 
    order_items.each do |order_item|
      if (order_item.product_id == :id)
        return true 
      else
        errors.add(:base, 'Product referenced in the OrderItems.')
        return false 
      end
    end 
  end  
end


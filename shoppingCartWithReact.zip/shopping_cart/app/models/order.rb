class Order < ActiveRecord::Base
  alias_attribute :name, :id
  belongs_to :user
  has_many :order_items, dependent: :destroy
  
  def total_price
    order_items.to_a.sum(&:price)
  end
end

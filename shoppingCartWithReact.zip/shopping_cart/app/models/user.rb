class User < ActiveRecord::Base
  alias_attribute :name, :email
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable and :omniauthable
  has_many :orders
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :trackable, :validatable

  
  before_destroy :check_for_in_complete_orders
  # @return [Boolean] user should be remembered when he logs in (with cookie)
  # so he won't be asked to login again

  # def create
  #   session[:current_user_id] = @user.id
  #   User.find(session[:current_user_id])
  # end

  def remember_me 
    true
  end
  def check_for_in_complete_orders
    orders.each do |order|
      if order.is_complete
        return true 
      else
        errors.add(:base, 'User has in-complete Orders.')
        return false 
      end
    end 
  end  
end


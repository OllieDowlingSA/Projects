class OrderItem < ActiveRecord::Base
  
  belongs_to :order
  belongs_to :product
  validates :order_id, :presence => true
  validates :product_id, :presence => true
  validates :price, numericality: {greater_than_or_equal_to: 0.01}, :presence => true
  alias_attribute :name, :id
end

